package com.Springboot.CurdOperationProject;

import com.Springboot.CurdOperationProject.entities.User;
import com.Springboot.CurdOperationProject.repo.UserRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

@SpringBootApplication
public class CurdOperationProjectApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(CurdOperationProjectApplication.class, args);

		UserRepository userRepository = context.getBean(UserRepository.class);

		User user1 = new User();
		user1.setName("Dipali Sonone");
		user1.setCity("Pune");
		user1.setStatus("Java Developer");

	    User result = userRepository.save(user1);
		System.out.println(user1);

		//Create

		//User user2 = new User();
		//user2.setName("Arjun");
		//user2.setCity("Mumbai");
		//user2.setStatus("Data Analyst");

		//List<User> users = List.of(user1,user2);
		//save multiple objects
		//Iterable<User> result = userRepository.saveAll(users);

		//result.forEach(user -> {
			//System.out.println(user);
		//});

		//System.out.println(" saved user "+resultUser);

		// UPDATE

		//Optional<User> optional = userRepository.findById(2);
		//User user = optional.get();

		//user.setName("Arjun");
		//User result1 = userRepository.save(user);

		//System.out.println(result1);

		// How to get data

		//Iterable<User> itr = userRepository.findAll();
		//itr.forEach(new Consumer<User>() {

		//	@Override
		//	public void accept(User t) {

		//	}
		//});


	}

}
