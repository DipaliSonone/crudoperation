package com.Springboot.CurdOperationProject.repo;

import com.Springboot.CurdOperationProject.entities.User;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<User, Integer> {
}
